---
name: Questions / Help / Support
about: Ask for help, support or ask a question
title: "❓ Questions / Help / Support"
labels: help wanted
assignees: snakers4

---

## ❓ Questions and Help

We have a [wiki](https://github.com/snakers4/silero-models/wiki) available for our users. Please make sure you have checked it out first.
